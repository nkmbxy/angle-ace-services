package com.project.angleace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngleAceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.project.angleace.exception;

import java.io.Serial;

public class Exception extends RuntimeException {
    @Serial
    private static final long serialVersionUID = 1L;
}

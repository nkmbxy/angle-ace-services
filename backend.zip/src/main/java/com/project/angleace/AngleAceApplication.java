package com.project.angleace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngleAceApplication {

    public static void main(String[] args) {
        SpringApplication.run(AngleAceApplication.class, args);
    }

}
